---
type: blogs
created : 2022-06-28 14:44
title: Home
tags : blogs
keywords : []
---

# Home
- 텍스트를 기반으로하여 빠르게 글 작성 및 공유하는 페이지
- 더 자세한 내용 또는 이미지를 추가하여 작성할때는 tistory 블로그에 작성
	- [민트로피의 민트초코](https://mintropy.tistory.com/)

# Index
- [[(algorithm]]
- [[(디자인패턴]]
