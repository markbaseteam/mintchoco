---
type: blogs
created : 2022-06-28 16:00
title: (algorithm
tags : blogs
keywords : []
---

# (algorithm
- [BAEKJOON](https://www.acmicpc.net/)
	- [백준 프로필](https://www.acmicpc.net/user/jun2korea)
	- [solved.ac 프로필](https://solved.ac/profile/jun2korea)

# 규칙
- 제목은 `BOJ0000`형태(문제출처+번호)
	- 작성의 편리함도 있지만, 주소를 더욱편리하게 지정하기 위함
- 언어는 해당 제출 언어 설정 기준으로 작성
	- Python3의 경우, Python으로 표기
	- 그 외에는 Go, Node.js, TypeScript 등으로 표시
